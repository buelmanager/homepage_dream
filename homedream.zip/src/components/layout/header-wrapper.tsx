import { Header } from "./header";

export async function HeaderWrapper() {
  return <Header />;
}
